import java.util.List;

import bean.Treno;
import org.hibernate.*;
import org.hibernate.cfg.Configuration;
import java.util.Iterator;

public class testHibernate {

    private static org.hibernate.SessionFactory factory;

        public static void main(String[] args) {

            try {
                factory = new Configuration().configure().buildSessionFactory();
            } catch (Throwable ex) {
                System.err.println("Failed to create sessionFactory object." + ex);
                throw new ExceptionInInitializerError(ex);
            }

            TestTrenoHibernate ME = new TestTrenoHibernate();

            /* Add few employee records in database */
	      /*Integer empID1 = ME.addEmployee("Zara", "Ali", 1000);
	      Integer empID2 = ME.addEmployee("Daisy", "Das", 5000);
	      Integer empID3 = ME.addEmployee("John", "Paul", 10000);*/

            Integer t1 = ME.addTreno("HCCC", "in costruzione");
            
            System.out.print(t1);

            Session session = factory.openSession();
            Transaction tx = null;

          //Criteria example
	      /*Criteria cr = session.createCriteria(Employee.class);
	      cr.add(Restrictions.eqOrIsNull("salary",5000));
	      List results = cr.list();*/

            //HQL example
	      /*String hql = "FROM Employee E WHERE E.firstName = :name";
	      Query query = session.createQuery(hql);
	      query.setParameter("name", "Zara");
	      List results = query.list();*/

            String hql = "FROM Treno T WHERE T.stato = :stato";
            Query query = session.createQuery(hql);
            query.setParameter("stato", "pronto");
            List results = query.list();

            //SQL native
	      /*String sql = "SELECT * FROM Employee WHERE E.id = :id";
    	  Query query = session.createSQLQuery(sql);
    	  query.setParameter("id", 1);
    	  List results = query.list();*/

            //---- importato per stampare dati
            try {
                tx = session.beginTransaction();
                for (Iterator iterator = results.iterator(); iterator.hasNext();){
                    Treno treno = (Treno) iterator.next();
                    System.out.print("Stato del treno " + treno.getIdTreno() + ": " + treno.getStato()+"\n");
                }
                tx.commit();
            } catch (HibernateException e) {
                if (tx!=null) tx.rollback();
                e.printStackTrace();
            } finally {
                session.close();
            }

            //---- fine importazione

            /* List down all the employees */
            ME.listEmployees();

            /* Update employee's records */
            //ME.updateEmployee(empID1, 5000);

            /* Delete an employee from the database */
            //ME.deleteEmployee(empID2);

            /* List down new list of the employees */
            //ME.listEmployees();
        }

        /* Method to CREATE an employee in the database */
        public Integer addTreno(String sigla, String stato){
            Treno treno = null;
            Session session = factory.openSession();
            Transaction tx = null;

            try {
                tx = session.beginTransaction();
                treno = new Treno(sigla, stato);

                //treno.setId(1000);

                session.persist(treno);

                //employee.setFirstName("PLUTO");

                // qui employee è persistente



                tx.commit();



            } catch (HibernateException e) {
                if (tx!=null) tx.rollback();
                e.printStackTrace();
            } finally {
                session.close();
            }


            return treno.getIdTreno();
        }

        /* Method to  READ all the employees */
        public void listEmployees( ){
            Session session = factory.openSession();
            Transaction tx = null;

            try {
                tx = session.beginTransaction();
                List treni = session.createQuery("FROM Treno").list();
                for (Iterator iterator = treni.iterator(); iterator.hasNext();){
                    Treno treno = (Treno) iterator.next();
                    System.out.print("Treno : " +treno.getIdTreno() + ", stato: "+ treno.getStato()+"\n");
                }
                tx.commit();
            } catch (HibernateException e) {
                if (tx!=null) tx.rollback();
                e.printStackTrace();
            } finally {
                session.close();
            }
        }

        /* Method to UPDATE salary for an employee */
        public void updateEmployee(Integer TrenoID, String stato ){
            Session session = factory.openSession();
            Transaction tx = null;

            try {
                tx = session.beginTransaction();
                Treno employee = (Treno)session.get(Treno.class, TrenoID);
                employee.setStato( stato );
                session.update(employee);
                tx.commit();
            } catch (HibernateException e) {
                if (tx!=null) tx.rollback();
                e.printStackTrace();
            } finally {
                session.close();
            }
        }

        /* Method to DELETE an employee from the records */
        public void deleteEmployee(Integer TrenoID){
            Session session = factory.openSession();
            Transaction tx = null;

            try {
                tx = session.beginTransaction();
                Treno employee = (Treno)session.get(Treno.class, TrenoID);
                session.delete(employee);
                tx.commit();
            } catch (HibernateException e) {
                if (tx!=null) tx.rollback();
                e.printStackTrace();
            } finally {
                session.close();
            }
        }

}
