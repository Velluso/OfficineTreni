package bean;

public class ItaloCargo extends Cargo {

	public ItaloCargo() {
		super();
	}

	public ItaloCargo(int peso, int prezzo, int lunghezza, String compagnia, int capienzaPeso) {
		super(peso, prezzo, lunghezza, compagnia, capienzaPeso);
	}

	
	
	

}
