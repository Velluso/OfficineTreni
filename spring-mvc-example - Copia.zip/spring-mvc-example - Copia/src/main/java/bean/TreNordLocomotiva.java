package bean;

public class TreNordLocomotiva extends Locomotiva {

	public TreNordLocomotiva() {
		super();
	}

	public TreNordLocomotiva(int peso, int prezzo, int lunghezza, String compagnia, int pesoTrainante) {
		super(peso, prezzo, lunghezza, compagnia, pesoTrainante);
	}	
	
}
