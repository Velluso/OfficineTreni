package bean;

public class FrecciarossaCargo extends Cargo {

	public FrecciarossaCargo() {
		super();
	}

	public FrecciarossaCargo(int peso, int prezzo, int lunghezza, String compagnia, int capienzaPeso) {
		super(peso, prezzo, lunghezza, compagnia, capienzaPeso);
	}
	

	
	
	

}
