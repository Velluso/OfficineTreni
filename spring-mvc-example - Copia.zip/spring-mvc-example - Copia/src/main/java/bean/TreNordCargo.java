package bean;

public class TreNordCargo extends Cargo {

	public TreNordCargo() {
		super();
	}

	public TreNordCargo(int peso, int prezzo, int lunghezza, String compagnia, int capienzaPeso, String tipoVagone) {
		super(peso, prezzo, lunghezza, compagnia, capienzaPeso);
	}
	
	
	
	
	

}
