package bean;

public class TreNordPasseggeri extends Passeggeri {

	public TreNordPasseggeri() {
		super();
	}

	public TreNordPasseggeri(int peso, int prezzo, int lunghezza, String compagnia, int postiDisponibili) {
		super(peso, prezzo, lunghezza, compagnia, postiDisponibili);
	}
	
}
