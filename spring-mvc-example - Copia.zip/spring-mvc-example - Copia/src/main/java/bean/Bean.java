package bean;

public interface Bean {

}
