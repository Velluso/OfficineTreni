package bean;

public class FrecciarossaLocomotiva extends Locomotiva {

	public FrecciarossaLocomotiva() {
		super();
	}

	public FrecciarossaLocomotiva(int peso, int prezzo, int lunghezza, String compagnia, int pesoTrainante) {
		super(peso, prezzo, lunghezza, compagnia, pesoTrainante);
	}	
	
}
