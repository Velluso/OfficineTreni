package bean;

public class TreNordRistorante extends Ristorante {

	public TreNordRistorante() {
		super();
	}

	public TreNordRistorante(int peso, int prezzo, int lunghezza, String compagnia, int copertiDisponibili) {
		super(peso, prezzo, lunghezza, compagnia, copertiDisponibili);
	}	
	
}
