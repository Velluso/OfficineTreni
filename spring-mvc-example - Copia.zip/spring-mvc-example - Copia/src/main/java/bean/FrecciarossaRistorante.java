package bean;

public class FrecciarossaRistorante extends Ristorante {

	public FrecciarossaRistorante() {
		super();
	}

	public FrecciarossaRistorante(int peso, int prezzo, int lunghezza, String compagnia, int copertiDisponibili) {
		super(peso, prezzo, lunghezza, compagnia, copertiDisponibili);
	}	
	
}
