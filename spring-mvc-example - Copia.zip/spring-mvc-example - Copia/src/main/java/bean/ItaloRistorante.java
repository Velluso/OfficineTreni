package bean;

public class ItaloRistorante extends Ristorante {

	public ItaloRistorante() {
		super();
	}

	public ItaloRistorante(int peso, int prezzo, int lunghezza, String compagnia, int copertiDisponibili) {
		super(peso, prezzo, lunghezza, compagnia, copertiDisponibili);
	}
	
}
