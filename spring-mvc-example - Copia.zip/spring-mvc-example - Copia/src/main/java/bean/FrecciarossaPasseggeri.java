package bean;

public class FrecciarossaPasseggeri extends Passeggeri {

	public FrecciarossaPasseggeri() {
		super();
	}

	public FrecciarossaPasseggeri(int peso, int prezzo, int lunghezza, String compagnia, int postiDisponibili) {
		super(peso, prezzo, lunghezza, compagnia, postiDisponibili);
	}
	
}
