package bean;

public class ItaloLocomotiva extends Locomotiva {

	public ItaloLocomotiva() {
		super();
	}

	public ItaloLocomotiva(int peso, int prezzo, int lunghezza, String compagnia, int pesoTrainante) {
		super(peso, prezzo, lunghezza, compagnia, pesoTrainante);
	}
	
	
}
