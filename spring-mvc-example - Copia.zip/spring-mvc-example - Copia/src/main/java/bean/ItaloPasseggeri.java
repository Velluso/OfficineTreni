package bean;

public class ItaloPasseggeri extends Passeggeri {

	public ItaloPasseggeri() {
		super();
	}

	public ItaloPasseggeri(int peso, int prezzo, int lunghezza, String compagnia, int postiDisponibili) {
		super(peso, prezzo, lunghezza, compagnia, postiDisponibili);
	}
	
}
