package eccezioni;

public class PosizioneRistoranteException extends TrenoException {
	
	public PosizioneRistoranteException(String messaggio,String sigla) {
		super(messaggio,sigla);
	}
}
