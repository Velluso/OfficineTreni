package service;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import bean.*;
import builder.GenericBuilder;
import eccezioni.*;

public class Main {

	private static SessionFactory factory; 
	 
	static {
		try {
			factory = new Configuration().configure().buildSessionFactory();
		} catch (Throwable ex) { 
			System.err.println("Failed to create sessionFactory object." + ex);
			throw new ExceptionInInitializerError(ex); 
		}
	}
	
	public static void main(String[] args){
			
		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("springBeansTreno.xml");
		/*GenericBuilder gb = (GenericBuilder) context.getBean("GenericBuilder");			//prove GenericBuilder+eccezioni
		Treno treno=(Treno) context.getBean("Treno");
		try {
			treno=gb.costruisciTreno("hpprppp");
		} catch (LocomotivaException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		} catch (VagoniIncompatibiliException e) {
			System.out.println(e.toString());
			e.printStackTrace();			
		} catch (PosizioneRistoranteException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		} catch (VagoneNonRiconosciutoException e) {
			System.out.println(e.getMessage()+" Elimina dalla sigla il carattere '"+e.getIntruso()+"'");
			e.printStackTrace();
		} catch (PesoTrainatoException e) {
			System.out.println(e.toString());
			e.printStackTrace();
		}
		System.out.println(treno);
		*/
		/*UtenteService service = new UtenteService(); 			//prove UtenteService
	    System.out.println(service);	      
	    Utente u = service.find(1);
	    u.setBudget(1850);
	    u.setEmail("prova");
	    service.update(u);*/
		/*VagoneService vs=new VagoneService();					//prove VagoneService
		System.out.println(vs);
		FrecciarossaLocomotiva fl = new FrecciarossaLocomotiva();
		ItaloCargo ic = new ItaloCargo();
		vs.create(fl);
		vs.create(ic);
		System.out.println(vs.find(2));
		fl.setPrezzo(500);
		vs.update(fl);*/
		/*OrdineService os = new OrdineService();					//prove OrdineService
		Ordine o =new Ordine(1,2,LocalDate.of(2023,7,21),LocalDate.of(2025, 1, 1),"bhoo");
		os.crea(o);*/
		TrenoService ts= (TrenoService) context.getBean("TrenoService");
		VagoneService vs= (VagoneService) context.getBean("VagoneService");
		GenericBuilder gb = (GenericBuilder) context.getBean("GenericBuilder");
		Treno t=(Treno) context.getBean("Treno");
		try {
			t=gb.costruisciTreno("hpprpp","Italo");
		} catch (VagoneNonRiconosciutoException | VagoniIncompatibiliException | LocomotivaException
				| PosizioneRistoranteException | PesoTrainatoException e) {
			e.printStackTrace();
		}
		System.out.println(t);
		//INSERIMENTO TRENO + VAGONI NEL DB IN TRANSAZIONE
		Session session = factory.openSession();
	    Transaction tx = null;	      
	    try {
	    	tx = session.beginTransaction();
	    	ts.crea(t);
			for(Vagone i:t.getTreno()) {
				vs.create(i);
			}
			tx.commit();
	    } catch (HibernateException e) {
	    	if (tx!=null) tx.rollback();
	        e.printStackTrace(); 
	    } finally {
	    	session.close(); 
	    }
		
		
	    
	}
}
