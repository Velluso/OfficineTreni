package factory;

public abstract class VagoniFactory {

}
