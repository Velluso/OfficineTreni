package factory;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import bean.*;

public class OrdineFactory{
	
	ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("springOrdiniTreno.xml");
	
	public Ordine creaOrdine() {
		return (Ordine) context.getBean("ordine");
	}
	
}
